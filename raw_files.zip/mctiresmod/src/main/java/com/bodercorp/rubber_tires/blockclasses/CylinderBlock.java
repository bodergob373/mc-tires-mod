package com.bodercorp.rubber_tires.blockclasses;

import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import com.bodercorp.rubber_tires.utilityclasses.CylinderBlockProperties;

public class CylinderBlock extends Block {

    public static final IntegerProperty FACING = IntegerProperty.create("facing", 0, 5);
    public static final IntegerProperty AXIS_ROTATION = IntegerProperty.create("axis_rotation", 0, 3);
    //public CylinderBlockProperties cylinderProperties;

    private static final VoxelShape HITBOX = Shapes.or(
        box(-8, -8, 4, 24, 24, 12),
        box(4, -14, 4, 12, 30, 12),
        box(-14, 4, 4, 30, 12, 12),
        box(-4, -12, 4, 20, 28, 12),
        box(-12, -4, 4, 28, 20, 12)
    );

    public CylinderBlock(Properties properties, CylinderBlockProperties cylinderProperties) {
        super(properties);
        //this.cylinderProperties = cylinderProperties;

        this.registerDefaultState(
                this.stateDefinition.any()
                        .setValue(FACING, 4)
                        .setValue(AXIS_ROTATION, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, AXIS_ROTATION);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return HITBOX; //generateHitbox(state.getValue(FACING), cylinderProperties);
    }

    public static VoxelShape generateHitbox(int facing, CylinderBlockProperties properties) {
        return null;
    }
}
