package com.bodercorp.rubber_tires.utilityclasses;

public class CylinderBlockProperties {
    public float diameter;
    public float height;
    public float offset;

    public CylinderBlockProperties(float diameter, float height, float offset) {
        this.diameter = diameter;
        this.height = height;
        this.offset = offset;
    }
}